{
  "stage_message_limit" : 1,
  "site_id" : 8992,
  "public_campaign_type_priority" : [ 1, 1 ],
  "multi_campaign_enabled" : true,
  "stage_campaign_type_priority" : [ ],
  "public_message_limit" : 1
}